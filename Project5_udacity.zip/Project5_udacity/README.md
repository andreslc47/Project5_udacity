# Project5_udacity

1. cd /home/robond
2. git clone https://github.com/andreslc47/Project5_udacity.git
3. cd Project5_udacity
4. ./compile_all
5. cd Project5_udacity/src/scripts
6. ./test_slam.sh
7. ./home/robond/Project5_udacity/pkill_all
8. ./test_navigation.sh
9. ./home/robond/Project5_udacity/pkill_all
10. ./pick_objects.sh
11. ./home/robond/Project5_udacity/pkill_all
12. ./add_marker.sh
13. ./home/robond/Project5_udacity/pkill_all
14. ./home_service.sh
15. ./home/robond/Project5_udacity/pkill_all
